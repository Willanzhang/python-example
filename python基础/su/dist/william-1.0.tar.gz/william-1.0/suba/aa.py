def test():
    print('aaa  test  嘻嘻')