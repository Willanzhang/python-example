from distutils.core import setup

setup(name="william", version="1.0", description="william's module", author="william", py_modules=['suba.aa', 'suba.bb', 'subb.cc', 'subb.dd'])